import chalk from 'chalk';

console.log(chalk.blue('Ola mundo!'));

console.log(chalk.red('Curso'));
